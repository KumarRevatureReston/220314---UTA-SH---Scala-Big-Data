# Mini-Game Project
## Benjamin Godfrey

> # 1. Mini-Game Project

My application Mini-Game was created in Scala programming language connected to Postgres database with the help of Slick library.
The Database restaurant was provided by Kumar.

# 2.	Basic functionality
The Mini-Game project reads from the restaurant database and creates a TableQuery[Restaurants] holding all the data contained in the
database. It is then modified or displayed by the user to earn points. The user may earn points by displaying the table, 
updating a row, adding a row or deleting a row. It takes 1000 points to win. Enjoy the game!
 