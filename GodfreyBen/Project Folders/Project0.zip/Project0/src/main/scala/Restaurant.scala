case class Restaurant(_id: String, address_building: String,address_coord: String,address_street: String,
address_zipcode: String,borough: String,cuisine: String,grades: String,name: String,restaurant_id: String){}

object Restaurant{
  def apply(_id: String, address_building: String,address_coord: String,address_street: String,
            address_zipcode: String,borough: String,cuisine: String,grades: String,name: String,restaurant_id: String):
            Restaurant = new Restaurant(_id, address_building,address_coord,address_street,
            address_zipcode,borough,cuisine,grades,name,restaurant_id)
}