import slick.jdbc.H2Profile.api._

import scala.concurrent.ExecutionContext.Implicits.global

object ScalaInput{
  var total_points = 0;
  var total_rows = 0;

  class Restaurants(tag: Tag) extends Table[(String, String, String, String, String, String, String,
    String, String, String)](tag, "SUPPLIERS") {
    def id = column[String]("ID", O.PrimaryKey) // This is the primary key column

    def address_building = column[String]("Address.Building")

    def address_coord = column[String]("Address.Coord")

    def address_street = column[String]("Address.Street")

    def address_zipcode = column[String]("Address.Zipcode")

    def borough = column[String]("Borough")

    def cuisine = column[String]("Cuisine")

    def grades = column[String]("Grades")

    def name = column[String]("Name")

    def restaurant_id = column[String]("Restaurant_id")

    override def * = (id, address_building,address_coord,address_street,
      address_zipcode,borough,cuisine,grades,name,restaurant_id)
  }

  val db = Database.forConfig("h2mem")

  def main(args: Array[String]): Unit = {
    var input = ""
    var result = 100;

    var table = fillTable()

    while(true) {
      try {
        println("Total Points: " + total_points)
        if (total_points >= 1000) {
          println("You win.")
          System.exit(0)
        }
        println("Please select your options for the restaurant database.")
        println("5: Prompt again.")
        println("4: Guessing Game for 1000 points!")
        println("3: Add a restaurant to the database for 10 points.")
        println("2: Modify a current restaurant for 10 points.")
        println("1: Display restaurant table for 10 points.")
        println("0: exit")
        println("Once your points hit 1000 you win!")
        print("Enter your choice here: ")
        input = scala.io.StdIn.readLine()
        result = input.toInt
      }catch{
        case n: java.lang.NumberFormatException => println("Not one of the options provided.")
        case _: Throwable => println("You did something weird.")
      }
      result match{
        case 0 => System.exit(0)
        case 1 => displayTable(table)
        case 2 => modifyCurrentAirport(table)
        case 3 => addsAirport(table)
        case 4 => guessingGame(table)
        case 5 =>
        case _ => println("You entered a number not within the options provided.")
      }
    }
  }
  def fillTable(): TableQuery[Restaurants] ={
    println("Table filled.")

    val restaurants = TableQuery[Restaurants]

    val setup = DBIO.seq(
      restaurants.schema.create
    )

    val setupFuture = db.run(setup)

    val bufferedSource = io.Source.fromFile("src/main/scala/Restaurants.csv")
    for (line <- bufferedSource.getLines) {
      val cols = line.split(",").map(_.trim)
      var restaurant = new Restaurant(s"${cols(0)}",s"${cols(1)}", s"${cols(2)}",
        s"${cols(3)}", s"${cols(4)}",s"${cols(5)}",s"${cols(6)}",
        s"${cols(7)}",s"${cols(8)}",s"${cols(9)}")

      var result = restaurants.forceInsert(s"${cols(0)}",s"${cols(1)}", s"${cols(2)}",
           s"${cols(3)}", s"${cols(4)}",s"${cols(5)}",s"${cols(6)}",
           s"${cols(7)}",s"${cols(8)}",s"${cols(9)}")
      db.run(result)


      total_rows = total_rows + 1
    }
    bufferedSource.close

    return restaurants
  }

  def displayTable(table: TableQuery[Restaurants]): Unit = {
    val tablequery = table.map(_.id)
    val action = tablequery.result
    val result = db.run(action)
    result.foreach(id => id.foreach(new_id => println(new_id)))

    total_points = total_points + 10
  }

  def modifyCurrentAirport(table: TableQuery[Restaurants]): Unit ={
    println("Modify a row by selecting with an id.")
    var input = scala.io.StdIn.readLine()
    var result = table.filter(_.id === input)
    println(result)
    println("Please choose how you would like to modify the query.")
    println("1. Update row")
    println("2. Delete row")
    print("Please enter here: ")
    var input1 = scala.io.StdIn.readLine()
    input1.toInt match {
      case 1 => {
        println("What would you like to change the restaurant ID to?")
        print("Please enter the new ID here: ")
        var input2 = scala.io.StdIn.readLine()
        val updateNameAction = table.filter(_.id === input).map(_.id).update(input2)
        db.run(updateNameAction)
      }

      case 2 => {
        val deleteAction = table.filter(_.id === input).delete
        db.run(deleteAction)
      }
    }
    total_points = total_points + 10
  }

  def addsAirport(table: TableQuery[Restaurants]): Unit = {
    var id = ""
    var address_building = ""
    var address_coord = ""
    var address_street = ""
    var address_zipcode = ""
    var borough = ""
    var cuisine = ""
    var grades = ""
    var name = ""
    var restaurant_id = ""
    try {
      println("_id")
      print("Enter your choice here: ")
      id = scala.io.StdIn.readLine()
      println("address.building")
      print("Enter your choice here: ")
      address_building = scala.io.StdIn.readLine()
      println("address.coord")
      print("Enter your choice here: ")
      address_coord = scala.io.StdIn.readLine()
      println("address.street")
      print("Enter your choice here: ")
      address_street = scala.io.StdIn.readLine()
      println("address.zipcode")
      print("Enter your choice here: ")
      address_zipcode = scala.io.StdIn.readLine()
      println("borough")
      print("Enter your choice here: ")
      borough = scala.io.StdIn.readLine()
      println("cuisine")
      print("Enter your choice here: ")
      cuisine = scala.io.StdIn.readLine()
      println("grades")
      print("Enter your choice here: ")
      grades = scala.io.StdIn.readLine()
      println("name")
      print("Enter your choice here: ")
      name = scala.io.StdIn.readLine()
      println("restaurant_id")
      print("Enter your choice here: ")
      restaurant_id = scala.io.StdIn.readLine()
      var result = table.forceInsert(id, address_building, address_coord, address_street, address_zipcode,borough,cuisine,grades, name,
        restaurant_id)
      db.run(result)
    }catch{
      case n: java.lang.NumberFormatException => println("Not one of the options provided.")
      //case _: Throwable => println("You did something weird.")
    }

    total_points = total_points + 10
  }

  def guessingGame(table: TableQuery[Restaurants]): Unit = {
    total_points = total_points + 10
    println("Guess which restaurant has currently been chosen. 1 - " + total_rows)
    val r = scala.util.Random
    val selected = r.nextInt(total_rows + 1)
    print("Enter your guess here: ")
    var input = ""
    try {
      input = scala.io.StdIn.readLine()
    }catch {
      case e: java.lang.NumberFormatException => println("You did not enter a number.")
    }
    if(input == selected){
      println("You win!")
      System.exit(0)
    }else{
      println("Better luck next time.")
    }
  }

}
