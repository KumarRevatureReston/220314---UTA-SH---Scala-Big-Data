import java.sql.{Connection, DatabaseMetaData, DriverManager, ResultSet, ResultSetMetaData, SQLException, Statement}
import java.io.{File, FileNotFoundException}
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.break


trait OutputFunctions {

  def printRed(str: String) = {
    Console.println("\u001b[31m" + str + "\u001b[0m")
  }

}

object PostGreSQL extends OutputFunctions {

  classOf[org.postgresql.Driver]
  val DB_NAME = "airports"
  val DB_USER = "postgres"
  val DB_PASS = "Padren911!"
  val con_str = "jdbc:postgresql://localhost:5432/" + DB_NAME + "?user=" + DB_USER + "&password=" + DB_PASS
  //Connects to the PostGreSQL database and stores metadata
  val conn = DriverManager.getConnection(con_str)
  val DB_MetaData : DatabaseMetaData =
    {
      try
      {
        println("Connecting to database...")
        conn.getMetaData()
      }
      catch
      {
        case e: SQLException => {
          println("Error connecting to database: " + e)
          null
        }
      }

    }

  // Send a Update/Create/Delete query to database
  def updateTable(sql: String): Unit = {

    val statement = conn.createStatement()
    statement.executeUpdate(sql)

  }

  // return 2d array of strings
  //Send a Read query to database
  def selectFromTable(query: String): Any = {

    var swap = ""
    var select_split = query.split(" ")
    select_split.foreach(arg => {
      swap = arg.replace(",", "")
      select_split.drop(select_split.indexOf(arg))
      select_split.update(select_split.indexOf(arg), swap)
    })

    var columns = select_split.slice(1, select_split.indexOf("FROM"))
    val statement = conn.createStatement()
    val resultSet = statement.executeQuery(query)

    var rows = Seq[Object]()
    //var rows = Seq[(String, String)]()
    // create a sequence of tuples

    val rsMetaData = resultSet.getMetaData()
    val count = rsMetaData.getColumnCount()
    var rowNames = Seq[String]()
    val colName = ""
    for (i <- 1 to count)
    {
      var nextColName = colName
      nextColName += rsMetaData.getColumnName(i)
      //adds spacing to end of column name
      for (j <- nextColName.length to 16)
        {
          nextColName += " "
        }
        rowNames = rowNames :+ nextColName
    }
    println(rowNames)
    println("---------------------------------------------------------------------------------------")
    while(resultSet.next()){
      // TODO pad the sequence with the number of getTableColumns
      //println()
      //columns.foreach(arg => print("   "+resultSet.getString(arg)))
      //
      var row = Seq[String]()
      for (i <- 1 to resultSet.getMetaData.getColumnCount) {
        // for each iteration expand the tuple
        //row = row.copy(_2 = resultSet.getString(i))
        val spacing = 16
        var dataString = "NULL"
        if (resultSet.getString(i) != null)
        {
          dataString = resultSet.getString(i)
        }
        var newDataString = dataString
        for (j <- dataString.length to spacing)
          {
            newDataString += " "
          }
        row = row :+ newDataString

      }
      rows = rows :+ row
    }
    rows.foreach{ r => println(r)}
    println("---------------------------------------------------------------------------------------")
    rows
  }

  def closeConnection(): Unit = {
    conn.close()
  }

} // end postgresql

object CSV{


  // (CALL FROM MAIN) Reads the CSV and returns everything as a String Seq
  def readCSV(f: String): Seq[Seq[String]] = {
    val bufferedSource = io.Source.fromFile(f)
    val lines = (for (line <- bufferedSource.getLines) yield line).toSeq
    bufferedSource.close
    var fLines = formatHeaders(lines)
    fLines
  }

  // (CALL FROM formatHeaders)
  def splitData(data: Seq[String]): Seq[Seq[String]] =
  {
    val newLines = for (line <- data) yield line.split(',').toSeq

    newLines
  }

  // (CALL FROM formatHeaders) Returns the appropriate data type for the column as a string
  def getHeaderTypes(data: Seq[Seq[String]]): Seq[String] =
  {
    var newHeads = ListBuffer[String]()
    val headNames = data(0)

    for ( col <- headNames)
    {

      val colIter = headNames.indexOf(col)
      val tStart = "varchar(50)"
      var tEnd = ""
      val checkFloat = "\\d+\\.+\\d+"
      var searching = true
      val maxSearches = 500
      var searchIter = 1
      var typeIter: Int = 0
      if (headNames.indexOf(col) == 0)
      {
        //searching = false
      }
      while (searching && searchIter < maxSearches && searchIter < data.size)
        {
          val row = data(searchIter)
          var d = ""
          if (colIter < row.size)
          {
            d = row(colIter)
          }
          var newEnd = ""
          //CHECK IF VARCHAR(50), INT, FLOAT
          if (d != "")
          {
            //IS IT A NUMBER
            if (d.forall(Character.isDigit))
            {
              if (d.matches(checkFloat))
              {
                newEnd = "float"
              } else { newEnd = "int" }
            } else { newEnd = "varchar(50)" }
            if (newEnd == tEnd)
            {
              typeIter += 1
            }
            tEnd = newEnd
          }

          searchIter += 1
          if (searchIter > maxSearches && typeIter < 5)
          {
            searching = false
          }
          if (typeIter >= 5)
          {
            tEnd = newEnd
            searching = false
          }

        }
      val newH = headNames(colIter) + " " + tEnd
      newHeads = newHeads :+ newH
    }
    newHeads.toSeq

  }

  // (CALL FROM readCSV) Takes the String Seq from readCSV and formats it for a PostGreSQL query
  def formatHeaders(data: Seq[String]): Seq[Seq[String]] =
  {
    // Seq[List[String]]
    var sData = splitData(data)
    // List[String]

    var formatted = sData
    // Updates the headers to be formatted
    formatted = formatted.slice(1, formatted.size)
    formatted = getHeaderTypes(sData) +: formatted

    formatted
  }



}

object airports extends App
{
  var keepRunning = true
  var files = List[File]()
  //Opens the connection to the database and stores metadata
  val dbMetaData = PostGreSQL.DB_MetaData

  // THIS NEEDS FIXING, CAN'T IMPORT VALUES FROM CSV
  def FormatImport(d: Seq[Seq[String]]): String = {
    //println("Thread " + i + " is running")
    //Thread.sleep(1000)
    var clock = 0
    var ticker = 0
    var stringout = ""
    for (row <- d)
    {
      var vstring = "("
      if (d.indexOf(row) > 0)
      {

        for (col <- row)
        {

          var formd = col.replaceAll("\"", "'")
          if (col == "")
            {
              formd = "NULL"
            }
          vstring += formd
          if (row.indexOf(col) < row.size)
          {
            vstring += ","
          }

        }
        //vstring += ","
      }

      if (d.indexOf(row) < d.size)
        {
          vstring += ", "
        }
      clock += 1
      if (clock > 500)
      {
        ticker += 1
        println ("Lines finished in thread: " + (500 * ticker) + "/" + d.size)
        clock = 0
      }
      vstring += ")"
      stringout += vstring

    }
    stringout
    //println("Thread " + i + " is finished")
  }

  //t1.start()
  //t2.start()
  //t3.start()
  // wait for all threads to finish
  //t1.join()
  //t2.join()
  //t3.join()

  //Views any files which are located in the '../src/main/resources' folder
  def ReadDirectory(): Unit =
  {
    val d = new File("src/main/resources")
    if (d.exists && d.isDirectory) {
      //files = d.listFiles.filter(_.isFile).toList
      files = d.listFiles((_,name: String) => name.toLowerCase.endsWith(".csv")).toList
    } else {
      List[File]()
    }
  }
  //Imports data from a CSV to the database
  def ImportDataTest(): Unit =
    {
      println("Select a file to import: ")
      val f = io.StdIn.readLine()
      println("Please wait...")
      try
      {

        val csvfile = CSV.readCSV("src/main/resources/" + f)
        val tableName = f.substring(0, f.lastIndexOf('.'))
        println("Formatting Table. Please Wait. This will take a bit...")
        var finishedq = "CREATE TABLE IF NOT EXISTS " + tableName + "("
        for (headcol <- csvfile(0))
        {
          var formd = headcol.replaceAll("\"", "")
          finishedq = finishedq + formd
          if (headcol != csvfile(0).last)
            {
              finishedq += ", "
            }
        }
        finishedq = finishedq + ");"
        //var splits = csvfile.drop(2)
        //var testsplits = splits.sliding(200,200).toList
        //finishedq += "INSERT INTO " + tableName + " VALUES "
        //var multistring = ""
        /*val t1 = new Thread(new Runnable {
          override def run(): Unit = {
            multistring += FormatImport(splits(0)) + ", "
          }
        })
        val t2 = new Thread(new Runnable {
          override def run(): Unit = {
            multistring += FormatImport(splits(1)) + ", "
          }
        })
        val t3 = new Thread(new Runnable {
          override def run(): Unit = {
            multistring += FormatImport(splits(2)) + ", "
          }
        })
        val t4 = new Thread(new Runnable {
          override def run(): Unit = {
            multistring += FormatImport(splits(3)) + ";"
          }
        })*/
        //t1.start()
        //t2.start()
        //t3.start()
        //t4.start()
        // wait for all threads to finish
        //t1.join()
        //t2.join()
        //t3.join()
        //t4.join()
        //multistring = multistring + FormatImport(testsplits(0)) + ";"
        //finishedq += multistring
        println(finishedq)
        PostGreSQL.updateTable(finishedq)
        println("Successfully imported!")

      } catch
      {
        case e: FileNotFoundException => println("There was an issue finding your file: " + e)
        case e: org.postgresql.util.PSQLException => println("There was an issue with your query: " + e)
      }
    }
  def ImportData(): Unit =
  {
    println("Select a file to import: ")
    val f = io.StdIn.readLine()
    println("Please wait...")
    try
      {

        val csvfile = CSV.readCSV("src/main/resources/" + f)
        val tableName = f.substring(0, f.lastIndexOf('.'))
        println("Formatting Table. Please Wait. This will take a bit...")
        var finishedq = "CREATE TABLE IF NOT EXISTS " + tableName + "("
        for (headcol <- csvfile(0))
          {
            var formd = headcol.replaceAll("\"", "")
            finishedq = finishedq + formd + ", "
          }
          finishedq = finishedq + ");"
        val bigstep = ((csvfile.size-1) / 4) + 1
        var splits = (csvfile.drop(1)).sliding(bigstep,bigstep).toList
        finishedq += " INSERT INTO " + tableName + " VALUES "
        var multistring = ""
        val t1 = new Thread(new Runnable {
          override def run(): Unit = {
            multistring += FormatImport(splits(0))
          }
        })
        val t2 = new Thread(new Runnable {
          override def run(): Unit = {
            multistring += FormatImport(splits(1))
          }
        })
        val t3 = new Thread(new Runnable {
          override def run(): Unit = {
            multistring += FormatImport(splits(2))
          }
        })
        val t4 = new Thread(new Runnable {
          override def run(): Unit = {
            multistring += FormatImport(splits(3))
          }
        })
        t1.start()
        t2.start()
        t3.start()
        t4.start()
        // wait for all threads to finish
        t1.join()
        t2.join()
        t3.join()
        t4.join()
        finishedq += multistring
        PostGreSQL.updateTable(finishedq)
        println("Successfully imported!")

      } catch
      {
        case e: FileNotFoundException => println("There was an issue finding your file: " + e)
        case e: org.postgresql.util.PSQLException => println("There was an issue with your query: " + e)
      }

  }
  //Returns a table and its columns to the CLI
  def PeekAtTable(): Unit =
  {
    classOf[org.postgresql.Driver]
    try
    {
      println("Tables: ")
      //store the metadata for tables in the database
      val tablers = dbMetaData.getTables(null, "public", "%", null)
      var i = 1
      while(tablers.next())
      {
        println(i + ") " + tablers.getString(3))
        i += 1
      }
      println("Select a table name: ")
      val q = io.StdIn.readLine()
      //Sends a query to the database
      val stm = PostGreSQL.conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
      //ReturnSet of all columns from table q
      val rs = stm.executeQuery("SELECT * FROM " + q)
      val rsMetaData = rs.getMetaData()
      println("Table columns: ")
      val count = rsMetaData.getColumnCount()
      for (i <- 1 to count)
      {
        //Prints the column variable type and name
        println(i + ") " + rsMetaData.getColumnTypeName(i)+" "+rsMetaData.getColumnName(i))
      }
    } catch
    {
        case e: org.postgresql.util.PSQLException => println("There was an issue with your query: " + e)
    }

  }
  //Returns the available commands to the CLI
  def PrintCommandOptions(): Unit =
    {
      println("Commands: ")
      println("I - Import directory files to database")
      println("IT - Import directory files to database (for testing)")
      println("F - View files in directory")
      println("P - Peek at database table")
      println("R - Read data in database table")
      println("U - Update/Create/Delete data in database")
      println("E - Exit program")
    }
  //CLI command to view all files located in the '../src/main/resources' folder
  def ViewFiles(): Unit =
  {

    for (file <- files)
    {
      val fn = file.toString().substring(19)
      println(fn)

    }
  }
  //Send a Read query to the database
  def ReadDatabase(): Unit =
  {
    println("Type query to read from database")
    val q = io.StdIn.readLine()
    try
    {
      val arr = PostGreSQL.selectFromTable(q)
      println(arr)
    } catch
    {
      case e: org.postgresql.util.PSQLException => println("There was an issue with your query: " + e)
    }
  }
  //Send a Create/Update/Delete query to the database
  def UpdateDatabase(): Unit =
  {
    println("Type query to create/update/delete data")
    val q = io.StdIn.readLine()
    try
    {
      val arr = PostGreSQL.updateTable(q)
      println("Database updated.")
    } catch
    {
      case e: org.postgresql.util.PSQLException => println("There was an issue with your query: " + e)
    }
  }
  //Quit the CLI and close the connection
  def QuitApp(): Unit =
  {
    println("Goodbye.")
    PostGreSQL.closeConnection()
    keepRunning = false;
  }

  ReadDirectory()
  PrintCommandOptions()

  while(keepRunning)
    {
      println("Enter a command: ")
      val cmd = io.StdIn.readLine().toUpperCase()
      cmd match
      {
        case "I" => ImportData()
        case "IT" => ImportDataTest()
        case "F" => ViewFiles()
        case "P" => PeekAtTable()
        case "R" => ReadDatabase()
        case "U" => UpdateDatabase()
        case "E" => QuitApp()
        case "?" => PrintCommandOptions()
        case _ => println("Unknown command. Try using '?' to see command options.")
      }
    }


}

