package example
import scala.concurrent.{Future, Await}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration._
import slick.backend.DatabasePublisher
import slick.basic.DatabaseConfig
import slick.driver.PostgresDriver.api._
import org.postgresql.translation.messages_bg
import scala.concurrent.Await
import scala.annotation.implicitNotFound

import scala.io.StdIn.readLine
import scala.io.StdIn.readChar;
import scala.io.StdIn.readBoolean;


// The main application
object BankAccount extends App {
    
    val db = Database.forConfig("postgres1");
    case class BankAccount(acc_num: Int, cli_name: String, cli_lastname: String,
                           acc_type: String,acc_monthfee: Int,acc_pass: String,
                           acc_interest_rate: Float,acc_status: String,acc_balance: Float);
    class BankAccounts(tag: Tag) extends Table[BankAccount](tag, "bankaccount"){
        override def * =(acc_num,cli_name,cli_lastname,acc_type,acc_monthfee,
                acc_pass,acc_interest_rate,acc_status,acc_balance)<>(BankAccount.tupled,BankAccount.unapply)
        val acc_num: Rep[Int]= column[Int]("acc_num",O.PrimaryKey)
        val cli_name= column[String]("cli_name")
        val cli_lastname:Rep[String]= column[String]("cli_lastname")
        val acc_type:Rep[String]= column[String]("acc_type")
        val acc_monthfee:Rep[Int]= column[Int]("acc_montfee")
        val acc_pass:Rep[String]= column[String]("acc_pass")
        val acc_interest_rate:Rep[Float]= column[Float]("acc_interest_rate")
        val acc_status:Rep[String]= column[String]("acc_status")
        val acc_balance:Rep[Float]= column[Float]("acc_balance")
    }
    val bankaccount = TableQuery[BankAccounts]
    def functionCount():Int=
    {
        //----Count all fields in the data base
        val queryCount = bankaccount.length
        val accounts: Future[Int]=db.run[Int](queryCount.result)
        val number_rows = Await.result(accounts, 2.seconds)
        return number_rows
    }

    def functionSelectAll()
    {
        var number_rows=functionCount();

        
        //val accountQuery:DBIO[Seq[String]] =sql"""select "name" from "Player" where "country" = 'Spain' """.as[(String,String)]
        
        //-----Select all rows
        val allRowsQuerySelect = bankaccount.take(number_rows)
        val allRows: Future[Seq[BankAccount]] = db.run[Seq[BankAccount]](allRowsQuerySelect.result)
        val result = Await.result(allRows, 2.seconds)

        for(x<-0 to number_rows-1)
        {
            val y=result(x)
            println(y.acc_num+"\t"+y.cli_name+"\t"+y.cli_lastname+"     "+
                "\t"+y.acc_type+"    \t"+y.acc_monthfee+"\t"+y.acc_interest_rate+
                "\t"+y.acc_status+"\t"+y.acc_balance);

        }


    }

    def functionInsertRows()
    {
        /*val insert:DBIO[Int]=bankaccount+=(4,"Marie","BA","PHYSICS");
        val insertAction: Future[Int] = db.run(insert);
        val rowCount =  Await.result(insertAction, 2.seconds)*/
    }
    
    functionMain();
  
    def clrscr() :Unit =
    {
        print("\u001b[2J");
        print("\u001b[H");
    }
    
    def mainMenu()
    {
        clrscr();
        while(true)
        {
        println("            BANK MENU\n");
        println("1. MANAGE ACCOUNTS");
        println("2. ACCOUNT TRANSACTION")
        println("3. EXIT\n")
        print("Select an Option : ")
        val input = readLine().toString;
        input match 
        {
            case "1"=>accountManage();
            case "2"=>accountMenu();
            case "3"=>return;
            case _=>{clrscr;println("Wrong Option");}
        }
        }
    }

    def accountManage()
    {
        clrscr;
        while(true)
        {
        println("            MANAGE ACCOUNT MENU\n");
        println("1. SEARCH ACCOUNT");
        println("2. LIST ACCOUNTS")
        println("3. OPEN ACCOUNT");
        println("4. EDIT ACCOUNT")
        println("5. CLOSE ACCOUNT");
        println("6. ERASE ACCOUNT");
        println("7. EXIT\n")
        print("Select an Option : ")
        val input = readLine().toString;
        input match 
        {
            case "1"=>searchAccountMenu();
            case "2"=>listAccountsMenu();
            case "3"=>openAccountMenu();
            case "4"=>editAccountMenu();
            case "5"=>closeAccountMenu();
            case "6"=>eraseAccountMenu();
            case "7"=>{clrscr();return;}
            case _=>{clrscr;println("Wrong Option");}
        }
        }
    }

    def searchAccount(acc:Int):Boolean=
    {
        //------Search by filter
        val querySelectAcc = bankaccount.filter(_.acc_num === acc)
        val searchRow: Future[Seq[BankAccount]] = db.run[Seq[BankAccount]](querySelectAcc.result)
        val result = Await.result(searchRow, 2.seconds)
       
        if(result.length>0)
        {
            val acc_num = result(0).acc_num
            val cli_name = result(0).cli_name
            val cli_lastname = result(0).cli_lastname
            val acc_type = result(0).acc_type
            val acc_montfee = result(0).acc_monthfee
            val acc_interest_rate = result(0).acc_interest_rate
            val acc_status = result(0).acc_status
            val acc_balance = result(0).acc_balance
            println(acc_num+"\t"+cli_name+"\t"+cli_lastname+"       "+
                    "\t"+acc_type+"    \t"+acc_montfee+"\t"+acc_interest_rate+
                    "\t"+acc_status+"\t"+acc_balance);
            return true;
        }
        else
            println("Account not found")
        return false;
    }

    def searchAccountMenu():Int=
    {
        clrscr();
        print("Enter the Account Number: ")
        var correct=true;
        while(correct)
        {
        try
        {
            var input= readLine().toInt
            correct=false;
            searchAccount(input);
        }
        catch{
            case e:NumberFormatException=>println("Wrong account number");
        }
        }
        readBoolean;
        clrscr;  

        return 1;
    }
    
    
    def listAccountsMenu():Unit=
    {
        clrscr();
        functionSelectAll()
        readBoolean;
        clrscr();
        
        
    }
    def openAccountMenu():Unit=
    {
        clrscr();
        print("Enter your name : ");
        val name=readLine().toString;
        print("Enter your lastname : ");
        val lastname=readLine().toString();
        var correct=false;
        var type_opt='L';
        var acc_type="";
        while(correct==false)
        {
            println("ENTER c for 'Checking' Account and s for 'Saving' Account")
            type_opt=readChar;
            if(type_opt=='C' || type_opt=='c')
            {
            acc_type="CHECKING";
            correct=true;
            }
            else if(type_opt=='s' || type_opt=='S')
            {
            acc_type="SAVING";
            correct=true;
            }
            else
            println("Wrong option");
        }
        var acc_montfee=0;
        var acc_interest_rate=0.0;
        if (acc_type=="SAVING")
        {
            acc_montfee=0;
            acc_interest_rate=2;
        }
        else
        {
            acc_montfee=12;
            acc_interest_rate=0
        }

        var password="";
        var passconf="-1";
        var exitpass=false;
        while(exitpass==false)
        {
            print("Enter you password: ");
            password=readLine().toString();
            print("Confirm password: ")
            passconf=readLine().toString();
            if(password==passconf)
                exitpass=true
            else
            {
                println("Wrong Password");
            }
        }
        println("CONFIRM CORRECT DATA")
        println("Name: "+name)
        println("Lastname: "+lastname)
        println("Account Type: "+acc_type)
        print("Are you sure (y to continue) :")
        var answer=readChar;
        if(answer=='y' || answer=='Y')
        {
                val size=functionCount();
                var next_acc_num= -1;
                
                //----Autogenerated num_acc
                if(size>0)
                {
                    val nextQuery:DBIO[Seq[Int]] =sql"select Max(acc_num) from bankaccount".as[Int]
                    val nextRow: Future[Seq[Int]] = db.run(nextQuery)
                    val result = Await.result(nextRow, 2.seconds)
                    next_acc_num = result(0)+1
                }
                else
                    next_acc_num=1;
                //-------------------------


                println("Your Account is "+next_acc_num)
                println("Enter inicial balance: ")
                val balance=readLine().toDouble;
                
                //---Insert Data into the table
                
                val newAccount:BankAccount=new BankAccount(next_acc_num, name, lastname, acc_type,
                                                    acc_montfee, password, acc_interest_rate.toFloat, "ACTIVE", balance.toFloat);

                val insert:DBIO[Int]=bankaccount+=newAccount;
                val insertAction: Future[Int] = db.run(insert);
                val rowCount =  Await.result(insertAction, 2.seconds)
                
                println("Account Open")
                readBoolean();
        }
        else
            return;
    }

    def editAccountMenu():Unit=
    {
        clrscr();
        var correct=true;
        while(correct)
        {
            try
            {
                print("Enter the Account Number: ")
                var input= readLine().toInt
                correct=false;
                if(searchAccount(input))
                {

                    //-----Select all full row
                    val rowsQuerySelect = bankaccount.filter(_.acc_num === input)
                    val allRows: Future[Seq[BankAccount]] = db.run[Seq[BankAccount]](rowsQuerySelect.result)
                    val result = Await.result(allRows, 2.seconds)
                    
                    var cli_name = result(0).cli_name;
                    var cli_lastname = result(0).cli_lastname;
                    var acc_pass = result(0).acc_pass;        
                    while(true)
                    {
                        clrscr();
                        println("1. NAME: "+cli_name)
                        println("2. LASTNAME: "+cli_lastname)
                        println("3. PASSWORD")
                        println("4. EXIT")
                        print("\nSelect option you want to edit: ")
                        var option=readLine().toString();
                        option match 
                        {
                        case "1"=>{
                                    print("Enter name: ")
                                    cli_name=readLine().toString();
                                    println("Name modified correclty");
                                    readBoolean();
                                    }
                        case "2"=>{
                                    print("Enter lastname: ")
                                    cli_lastname=readLine().toString();
                                    println("Lastame modified correclty");
                                    readBoolean();
                                    }
                        case "3"=>{
                                    var exitpass=false;
                                    var acc_passconf="";
                                    while(exitpass==false)
                                    {
                                        print("Enter you password: ");
                                        acc_pass=readLine().toString();
                                        print("Confirm password: ")
                                        acc_passconf=readLine().toString();
                                        if(acc_pass==acc_passconf)
                                        exitpass=true
                                        else
                                        {
                                            println("Wrong Password");
                                        }
                                    }                          
                                    println("Password modified correclty");
                                    readBoolean();
                                }
                        case "4"=>{
                                    //-------------Update Account--------------
                                    val updateName = bankaccount.filter(_.acc_num === input).map(_.cli_name).update(cli_name)
                                    val updateLastname = bankaccount.filter(_.acc_num === input).map(_.cli_lastname).update(cli_lastname)
                                    val updatePassword = bankaccount.filter(_.acc_num === input).map(_.acc_pass).update(acc_pass)
                                    //----Update Name
                                    val insertName: Future[Int] = db.run(updateName);
                                    val executeUpdateName =  Await.result(insertName, 2.seconds)
                                    //----Update LastName
                                    val insertLastname: Future[Int] = db.run(updateLastname);
                                    val executeUpdateLastname =  Await.result(insertName, 2.seconds)
                                    //----Update Password
                                    val insertPass: Future[Int] = db.run(updatePassword);
                                    val executeUpdatePass =  Await.result(insertName, 2.seconds)
                                    //-------------------

                                    clrscr();
                                    return;}
                        case _=>{clrscr;println("Wrong Option");}
                        }         
                    }
                }
            }
            catch{
                case e:NumberFormatException=>println("Wrong account number");
            }
        }   
    }
    def closeAccountMenu():Unit=
    {
        clrscr();
        print("Enter the Account Number: ")
        var correct=true;
        while(correct)
        {
        try
        {
            var acc= readLine().toInt
            correct=false;
            if(searchAccount(acc))
            {

                        //-----Select all full row
                val rowsQuerySelect = bankaccount.filter(_.acc_num === acc)
                val allRows: Future[Seq[BankAccount]] = db.run[Seq[BankAccount]](rowsQuerySelect.result)
                val result = Await.result(allRows, 2.seconds)

                val acc_status=result(0).acc_status;

                if(acc_status=="ACTIVE")
                {
                    print("Are you sure :")
                    var answer=readChar;
                    if(answer=='y' || answer=='Y')
                    {
                        //Update Status
                        val updateStatus = bankaccount.filter(_.acc_num === acc).map(_.acc_status).update("CLOSED")
                        val insertStatus: Future[Int] = db.run(updateStatus);
                        val executeUpdateStatus =  Await.result(insertStatus, 2.seconds)

                        //Update amount
                        val updateAmount = bankaccount.filter(_.acc_num === acc).map(_.acc_balance).update(0.0.toFloat)
                        val insertAmount: Future[Int] = db.run(updateStatus);
                        val executeUpdateAmount =  Await.result(insertAmount, 2.seconds)
                        
                        println("Account closed")
                        readBoolean();
                    }
                }
                else
                {
                    println("Account already CLOSED")
                    readBoolean();
                }
            }
        }
        catch{
            case e:NumberFormatException=>println("Wrong account number");
        }
        clrscr();
        }    
    }
    def eraseAccountMenu():Unit=
    {
        clrscr()
        val acc_num=checkAccountFormat();
        if(searchAccount(acc_num))
        {
            print("Are you sure to erase account permanently(y to confirm) :")
            var option=readLine().toString();
            if(option=="y" || option=='Y')
            {
                //------Delete Record
                val deleteAction = bankaccount.filter(_.acc_num === acc_num).delete
                val deleteStatus: Future[Int] = db.run(deleteAction);
                val deleteUpdateStatus =  Await.result(deleteStatus, 2.seconds)

                println("Account deleted");
                readBoolean();
                clrscr();
            }
            clrscr();
            return;
        }

    }
    
    def accountMenu()
    {
        clrscr();
        var acc_num=checkAccountFormat();
        if(account_verification(acc_num))
        {
            while(true)
            {
                println("            BANK ACCOUNT\n");
                println("1. MAKE A DEPOSIT");
                println("2. MAKE A WITHDRAWAL");
                println("3. VIEW  BALANCE");
                println("4. EXIT");
                print("\nSelect an option: ")
                val option=readLine().toString;
                option match 
                {
                case "1"=>accountDeposit(acc_num);
                case "2"=>accountWithdrawal(acc_num);
                case "3"=>accountBalance(acc_num);
                case "4"=>{clrscr;return}
                }
            }
        }        
    }


    def account_verification(input:Int):Boolean=
    {
        var passwordcount= 1;
        if(searchAccount(input))
        {
            clrscr();
                    //-----Select all full row
            val rowsQuerySelect = bankaccount.filter(_.acc_num === input)
            val allRows: Future[Seq[BankAccount]] = db.run[Seq[BankAccount]](rowsQuerySelect.result)
            val result = Await.result(allRows, 2.seconds)
            if(result(0).acc_status=="ACTIVE")
            {
                var acc_pass=result(0).acc_pass;
                while(true)
                {
                    if(passwordcount>3)
                    {
                    println("Exceed attempts")
                    readBoolean();
                    clrscr();
                    return false;
                    }
                    print("Enter you password: ");
                    var pass=readLine().toString();
                    if(acc_pass==pass)
                    return true;
                    else
                    println("Wrong password")
                    passwordcount+=1;
                }
            }
            else
            {
                println("Account is closed")
                readBoolean();
                clrscr();
            }
        } 
        return false;   
    }

    def checkAccountFormat():Int=
    {
        while(true)
        {
            try
            {
                print("Enter the number of the account: ")
                var input=readLine().toInt
                return input;
            }
            catch
            {
                case e:NumberFormatException=>println("Wrong account number");
            }
        }
        return -1;
    }

    def accountDeposit(acc_num:Int):Unit=
    {
        clrscr();
        var amount=0.00;
        var new_balance=0.00;
                //-----Select all full row
        val rowsQuerySelect = bankaccount.filter(_.acc_num === acc_num)
        val allRows: Future[Seq[BankAccount]] = db.run[Seq[BankAccount]](rowsQuerySelect.result)
        val result = Await.result(allRows, 2.seconds)
        
        
        val acc_balance=result(0).acc_balance.toFloat
        var correct=false
        while(correct==false)
        {
            try
            {
                print("Enter the amount to deposit: ")
                amount=readLine().toFloat;
                new_balance=acc_balance+amount
                //Update Status
                val updateBalance = bankaccount.filter(_.acc_num === acc_num).map(_.acc_balance).update(new_balance.toFloat)
                val insertBalance: Future[Int] = db.run(updateBalance);
                val executeUpdateBalance =  Await.result(insertBalance, 2.seconds)
                correct=true;
                println("The transaction was succesful")
            }
            catch
            {
                case e:NumberFormatException=>println("Inccorrect ammount")
            }
        }
        readBoolean;
        clrscr;  
    }

    def accountBalance(acc_num:Int):Unit=
    {
        //-----Select all full row
        val rowsQuerySelect = bankaccount.filter(_.acc_num === acc_num)
        val allRows: Future[Seq[BankAccount]] = db.run[Seq[BankAccount]](rowsQuerySelect.result)
        val result = Await.result(allRows, 2.seconds)

        val acc_balance=result(0).acc_balance.toFloat;
        println("The current balance of the account is : "+acc_balance)
        readBoolean;
        clrscr;  
    }
    def accountWithdrawal(acc_num:Int):Unit=
    {
        clrscr();
        var amount=0.00;
        var new_balance=0.00;
                //-----Select all full row
        val rowsQuerySelect = bankaccount.filter(_.acc_num === acc_num)
        val allRows: Future[Seq[BankAccount]] = db.run[Seq[BankAccount]](rowsQuerySelect.result)
        val result = Await.result(allRows, 2.seconds)

        val acc_balance=result(0).acc_balance.toFloat;
        var correct=false
        while(correct==false)
        {
        try
        {
            print("Enter the amount to withdraw: ")
            amount=readLine().toDouble;
            new_balance=acc_balance-amount
            //Update Status
            val updateBalance = bankaccount.filter(_.acc_num === acc_num).map(_.acc_balance).update(new_balance.toFloat)
            val insertBalance: Future[Int] = db.run(updateBalance);
            val executeUpdateBalance =  Await.result(insertBalance, 2.seconds)
            correct=true;
            println("The transaction was succesful")
        }
        catch
        {
            case e:NumberFormatException=>println("Inccorrect ammount")
        }
        }
        readBoolean;
        clrscr;  
    } 
    def functionMain() {
        mainMenu()    
        db.close()
    }      
        
}