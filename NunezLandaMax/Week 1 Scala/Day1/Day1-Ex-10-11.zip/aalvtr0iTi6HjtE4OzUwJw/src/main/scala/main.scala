var x=5 //Assign 5 to mutable variable x
val s=if(x>0 && x<6) 1 else 0 //Assign 1 to immutable variable s if x>0 and x<6 otherwise assign 0
object Demo_1{
  def main(args:Array[String])={
    var x=25;
    if(x>20)
      println("this is if statement")
  }
}