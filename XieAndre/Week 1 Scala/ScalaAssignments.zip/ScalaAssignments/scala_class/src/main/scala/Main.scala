//1. classes & objects
class Ctr {
  private var value = 6
  def incr(){
    value +=1
  }
  def curr() = value
}

class Duck {
  var size = 1
}

object Main extends App {
  //1.
  val ctr1 = new Ctr //instantiates ctr1 object from Ctr class
  ctr1.incr()
  println(ctr1.curr)

  var f = new Duck
  f.size = 1
  println(f.size)
  
  //2. 
  val emp = new Employee()

  //3. Higher order functions
  var salaries = Seq(20000, 70000, 40000)
  val doubleSalary = (x: Int) => x * 2
  var newSalaries = salaries.map(doubleSalary) //List(40000, 140000, 80000)

  //salaries = Seq(20000, 70000, 40000)
  newSalaries = salaries.map(x => x * 2)

  //println(doubleSalary)
  println(newSalaries)
}

//2. Structure of classes
//The auxiliary constructor in Scala is used for constructor overloading and defined as a method using this  name.
class Employee(empId: Int, name: String, salary: Double) {
  def this(empId: Int, name: String){
    this(0,"",0.0) //invoke primary constructor
    println("Two-argument auxiliary constructor")
  }
  def this(empId: Int){
    this(0,"",0.0) //invoke primary constructor
    println("one-argument auxiliary constructor")
  }
  def this(){
    this(0) //invokes one-argument auxiliary constructor
    println("Zero-argument auxiliary constructor")
  }
  println("Primary constructor")
}


