//1.Try/Catch
object TryCatch {
	def main(args: Array[String])
	{
		  val name = Map("abc" -> "author","pqr" -> "coder")
		  val x = name.get("abc")
		  val y = name.get("xyz")

		  println(x)  
		  println(y)  
	}
}

//2. without Exception Handling
class ExceptionExample1{  
    def divide(a:Int, b:Int) = {  
            a/b             // Exception occurred here  
        println("Rest of the code is executing...")  
    }  
}  

object NoExceptionHandle{  
    def main(args:Array[String]){  
        var e = new ExceptionExample1()  
        //e.divide(100,0)  //Because there is no Exception handling we receive a / by zero Exception
        e.divide(100,1)
    }  
}

//3. With Exception Handling
class ExceptionExample2{  
    def divide(a:Int, b:Int) = {  
        try{  
            a/b  
        }catch{  
            case e: ArithmeticException => println(e) //With try catch block, code still compiles and runs 
        }  
        println("Rest of the code is executing...")  
    }  
}  
object ExceptionHandle{  
    def main(args:Array[String]){  
        var e = new ExceptionExample2()  
        e.divide(100,0)  
   
    }  
}  

//4. Exception Handling "Finally"
class ExceptionExample3{  
    def divide(a:Int, b:Int) = {  
        try{  
            a/b  
            var arr = Array(1,2)  
            arr(10)  //Will always give exception because array index is out of bounds
        }catch{  
            case e: ArithmeticException => println(e)  
            case ex: Exception =>println(ex)  
            case th: Throwable=>println("found a unknown exception"+th)  
        }  
        finally{  
            println("Finally block always executes")  //Always executes 
        }  
        println("Rest of the code is executing...")  
    }  
}  

object ExceptionFinally{  
    def main(args:Array[String]){  
        var e = new ExceptionExample3()  
        e.divide(100,10)  
    }  
}  

//5. Pattern Matching
object PatternMatch extends App {
  println("enter number from 1 to 6")
  var a = scala.io.StdIn.readInt()
  a match {
      case 1 => println("One")
      case 2 => println("Two")
      case 3|4|5|6 => println("3, 4, 5, or 6")
      case _ => println("Out of bounds") // "_" = default case 
    }
  }

  object PatternMatch2 {
    def main(args: Array[String]) {
      var result = search ("Hello")
      print(result)
    }
    def search (a:Any):Any = a match{
      case 1 => println("One")
      case "Two" => println("Two")
      case "Hello" => println("Hello")
      case _ => println("No")
    }
  }

  //6. List
  object StudentList {
    def main(args:Array[String]) {
      //val numbersList: List[Int] = List(1, 2, 3 ,4)
      val emptyList: List[Int] = List()
      val numbersList: List[Int] = 1 :: 2 :: 3 :: 4 :: Nil

      println(numbersList)
      println(emptyList)

      val names= "Harry" :: ("Adam" :: ("Jill" :: Nil))
      val age = Nil
      println( "Head of names array : " + names.head )
      println( "Tail of names array : " + names.tail )
      println( "Check if names is empty : " + names.isEmpty )
      println( "Check if age is empty : " + age.isEmpty )
   }
}
