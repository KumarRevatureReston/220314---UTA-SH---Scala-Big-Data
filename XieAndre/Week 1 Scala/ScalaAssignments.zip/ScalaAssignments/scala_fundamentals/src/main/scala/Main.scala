import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.ListBuffer
import scala.io.Source


object Variable extends App {
  10 + 2 // requires computation value to be stored in a variable
  val a = 10 + 2
  println(a)
  //val msg = "Hello World"
  //msg = "Hello!" This wouldn't work because msg is declared as val making it unable to be updated
  var msg = "Hello World"// msg needs to be assigned as var in order to be mutable 
  msg = "Hello!" // reassigns msg to "Hello!"
  //msg = 3 this wouldn't work because type mismatch. Expects string but receives int
  println(msg)

  val x = {val a=10;val b=100; b-a}
  println(x)
  
  //val file = scala.io.Source.fromFile("kumar").mkString cannot find file "kumar" because it does not exist

  val  m = { print ("foo "); 1}
}

object IfStatement extends App {
  var x = 5
  val s = if (x> 0 && x<6) 1 else 0 //if else that uses && operation to check if both condition are true
  println(s)
  //vim Demo_1.scala not sure what this is supposed to do. Vim is a text editor and there is no method in Demo_1 called scala
  val t = if (x> 0 && x<6) "positive" else "negative"
  println(t)

  var args1 = "hello" //could not name args because compiler detects that as a type mismatch. Expects Array[String] and not string
  args1.foreach(arg=>println(arg))//foreach method works as a kind of for loop that iterates over the string elements and prints each element on a new line
  args1.foreach(println)//does the same process as the line above
}

object Loops extends App {
  val x = List(1,2,3)
  x.foreach{println} //prints each list element on a new line
  for(i <- 1 to 5) //for loop
  println(i)
  val in  = "hello world"
  var sum = 0
  for (i <- 0 until in.length) sum+=i //equivalent to the operation 1+2+3+4+5+6+7+8+9+10 = 55
  println(sum)
  for(i <- 1 to 3; j <- 1 to 3) //equivalent to (10*1+1), (10*1+2), ... ,(10*2+1), (10*2+2)
  println(10*i+j)
  
  for(i <- 1 to 3; j <- 1 to 3 if i==j) //same thing as above except with added conditions
  println(10*i+j)

  for(i <- 1 to 3; x= 4-i; j <- x to 3) 
  println(10*i+j + " hi") //hi was added so I can differentiate outputs

  val y = for (i <- 1 to 20) //changed x to y because x was already being used as a list variable
  yield i*2.5
  for (i <- y ) 
  println(i)

  //vim Demo_4.scala don't what this is suposed to do. Keep getting error exection EOL

  var nodb = 2
  do {
    nodb +=1
    println(s"nodb = $nodb")
  } while(nodb < 10)

}

object Functions {
  def sayhello(){
    println("Hello")
  }
  def sum(a: Int, b: Int){
    println(a+b)
  }
  def func(): Int = {
    return 7
  }

  //@overload
  def sum(a: Int, b: Any): Any = {
    println("hello")
  }

  def factorial(n:Int):Int=if(n==0)1 else n*factorial(n-1)

  def rect_area(length:Float,width:Float){
   val area = length*width; 
   println(area)
  }

  def main(args:Array[String]) { //calling defined functions
    sayhello()
    sum(2,6)
    println(func())
    sum(1,"string")
    println(factorial(5))
    rect_area(2,4)
  }
}

object RecursionFuncDemo{
  def main(args:Array[String]) = {
    var result= functionExamp(15,3) //equivalent to 15 + 15 + 15 + 0 = 45
    println(result)
  }
  def functionExamp(a:Int,b:Int):Int={
    if(b == 0)
    return 0
    else
    a+functionExamp(a,b-1) //function calls itself. Recursion step.
    } 
}


object ArrayExample extends App {
  var a = Array(1,2,3)//array with values
  //a(4) this creates an ArrayIndexOutOfBoundsException
  println(a(0)) //array index starts at 1
  a = new Array[Int](3)//array without values
  println(a(1))
  a(1) = 2
  println(a(1))

  //More empty array declarations
  a = new Array[Int](10)
  val s = new Array[String](10)
  println(s) //prints the memory address of s array
  //String array declaration
  val st = Array("Hello", "world")

  var x = ArrayBuffer[Int]() //allows for array contents to be added dynamically
  x += 1
  x += (2,3,5)
  x ++=Array(6,7,8)

  println(x)
}

object MoreListExample {
  def main(args:Array[String]) {
    var list = 1 :: 2 :: 3 :: Nil
    list = List(1,2,3)
    //val x = List(1,2.0,33D,4000L)
    //val x = List.range(1,10)
    //val x = List.fill(3)("foo")
    val L = List.tabulate(5)(n=>n*n)
    println(L)

    var fruits = ListBuffer[String]()
    fruits += "Apple"
    fruits += ("strawberry", "kiwi")
    fruits -= ("Apple", "kiwi")
    val fruitslists = fruits.toList //converts to list
    println(fruitslists)

    val x = List(3)
    val y = 1 :: 2 :: x //list concat
    val z = -1 :: y
    println(z)

    val originalList1 = List(7,8,4,3,2)
    val newList1 = originalList1.filter(_>3) //only includes elements that are greater than 3 in new list
    println(newList1)

    val p = List(111,200,321)
    val q = List(4,-5,60)

    var r = p ++ q //different ways to do the same prcoess of concatenation
    println(r)
    r = p ::: q
    println(r)
    r = List.concat(p,q)
    println(r)

    val lst = List(1,2,3,4,5,6,7,8)
    println(lst.head)
    println(lst.tail)
    val y1 = sum(lst)
    println(y1)
  
  }
  def sum(l: List[Int]):Int = {
    if(l == Nil)
      return 0
    else 
      l.head + sum(l.tail)
  }
}



//if statement demo
object Demo_1{ 
  def main(args:Array[String]) {
    var x=15;
    if( x<20) {
      println("This is if statement");
    }
  } 
}

//while loop demo
object Demo_4 { 
  def main(args:Array[String]) {
      var a=10;
      while( a<20) {
      println("value of a = " + a);
      a= a+1;
    }
  } 
}

//ReadInt
object ReadingInt extends App {
  var a=scala.io.StdIn.readInt()
  println("The value of a is "+ a)
}

//List
object ListExample {
  def main (args:Array[String]) {
    //val two dimensional = List[List[Int]]=List(List(1,0,0),List(2,0,0),List(3,0,0))
    val names = "Noah" :: ("Ben" ::("Brandon" :: Nil)) // Nil is an empty singleton object list that extends the List type
    val designation = Nil
      println("Head on names array: " + names.head)
      println("Tail on names array: " + names.tail)
      println("Check if designation is empty " + designation.isEmpty)
  }
}